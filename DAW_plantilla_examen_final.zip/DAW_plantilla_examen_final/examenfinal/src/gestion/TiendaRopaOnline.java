package gestion;


public class TiendaRopaOnline {
    
    //Apartado a)
    //Atributo HashMap
    
    //Apartado b)
    public TiendaRopaOnline(){
        
    }
    
    //Apartado c)
//    private Ropa encontrarRopa(String nombre){
//        
//    }
    
    //Apartado d)
    public void añadirRopa(String nombre,String marca,double precio,char temporada){
        
    }
    
    //Apartado e)
    public String toString() {
        String res="";
        
        return res;
    }
    
    //Apartado f)
    public String sumarPreciosMarcas() {
        String res="";
        
        return res;
    }
    
    //Apartado g)
    public String MasCaraTemporada(char temporada){
        String res="";
        
        return res;
    }
    
    //Apartado h)
    public void guardarRopas(String fichero){
        
    }
    
    //Apartado i)
    public void cargarRopas(String fichero){
        
    }
    
}
